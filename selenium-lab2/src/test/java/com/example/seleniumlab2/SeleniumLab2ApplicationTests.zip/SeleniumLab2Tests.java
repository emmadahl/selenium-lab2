package com.example.seleniumlab2;

import org.junit.jupiter.api.*;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

public class SeleniumLab2Tests {

    private static WebDriver driver;

    @BeforeAll
    static void setup() {
        ChromeOptions options = new ChromeOptions();
        options.addArguments("--remote-allow-origins=*");
        options.addArguments("incognito");
        driver = new ChromeDriver(options);
    }

    @BeforeEach
    void navigate() {
        driver.get("https://www.svtplay.se/");

    }

    @Test
    void checkWebsiteTitle() {
        /*HW lagt till och funkar?*/
        WebElement acceptCookies = driver.findElement(By.xpath("//button[text()= 'Acceptera alla']"));

        acceptCookies.click();
        /**/

        String websiteTitle = driver.getTitle();

        assertEquals("SVT Play", websiteTitle, "Title does not match");


    }

    @Test
    void checkWebsiteLogo() {
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        WebElement acceptCookies = driver.findElement(By.xpath("//button[text()= 'Acceptera alla']"));

        acceptCookies.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("sc-31022b15-0")));
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        Boolean result = driver.findElement(By.className("sc-31022b15-0")).isDisplayed();

        Assertions.assertTrue(result, "Logotype is not visible");


    }

    @Test
    void checkStartLinkName() {
        WebElement acceptCookies = driver.findElement(By.xpath("//button[text()= 'Acceptera alla']"));

        acceptCookies.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("ilPmDY")));

        WebElement startLink = driver.findElement(By.className("ilPmDY"));
        String startLinkText = startLink.getText();

        assertEquals("START", startLinkText, "Text does not match");

    }


    //Behöver skriva xpath på denna, ej unikt klassnamn
    @Test
    void checkProgramLinkName() {

        WebElement acceptCookies = driver.findElement(By.xpath("//button[text()= 'Acceptera alla']"));

        acceptCookies.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.className("bNIpCq")));

        WebElement programLink = driver.findElement(By.className("bNIpCq"));

        String programLinkText = programLink.getText();

        assertEquals("PROGRAM", programLinkText, "Text does not match");

    }

    //Behöver skriva xpath på denna, ej unikt klassnamn
    @Test
    void checkChanelLinkName() {

        //driver.manage().window().maximize();

        WebElement acceptCookies = driver.findElement(By.xpath("//button[text()= 'Acceptera alla']"));

        acceptCookies.click();

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/header/div[2]/div/div/nav/ul/li[3]/a")));

        WebElement chanelLink = driver.findElement(By.xpath("//*[@id=\"__next\"]/div/div[3]/div/header/div[2]/div/div/nav/ul/li[3]/a"));

        String chanelLinkText = chanelLink.getText();

        assertEquals("KANALER", chanelLinkText, "Text does not match");


    }
    //Den här gör så att resten failar CSS selector  + assertion?
    @Test
    void checkIfLinkIsDisplayed() {

        WebElement acceptCookies = driver.findElement(By.xpath("//button[text()= 'Acceptera alla']"));

        acceptCookies.click();
        /*WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//span[text()='Tillgänglighet i SVT Play']")));
        Boolean result = driver.findElement(By.xpath("//span[contains(@class, 'dmRxHt') and text()='Tillgänglighet i SVT Play']")).isDisplayed();

        Assertions.assertTrue(result, "Tillgänglighets link is not visible");

        */


        //HENRIK Nedan är original
        //wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.sc-87f10045-7:nth-child(2) > p:nth-child(1) > a:nth-child(1) > span:nth-child(2)")));

        //boolean availabilitySVTplay = driver.findElement(By.cssSelector("div.sc-87f10045-7:nth-child(2) > p:nth-child(1) > a:nth-child(1) > span:nth-child(2)")).isDisplayed();

        //System.out.println("The linktext status is" + availabilitySVTplay);
        //

    }

    //Den här gör så att resten failar CSS selector  + assertion?
    @Test
    void verifyLinkText() {

        // driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

        // acceptCookies.click();
        //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);


        WebElement acceptCookies = driver.findElement(By.xpath("//button[text()= 'Acceptera alla']"));
        acceptCookies.click();

        /*HENRIK hittar bara fel text :D

        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//*[contains(@class,'sc-343fed33-3')]")));
        String availabilityText = driver.findElement(By.xpath("//*[contains(@class,'sc-343fed33-3')]")).getText();

        assertEquals("Tillgänglighet i SVT Play", availabilityText, "Linktext does not match");
        */

        /* henrik original texten....
        WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(10));

        wait.until(ExpectedConditions.visibilityOfElementLocated(By.cssSelector("div.sc-87f10045-7:nth-child(2) > p:nth-child(1) > a:nth-child(1) > span:nth-child(2)")));

        WebElement availability = driver.findElement(By.cssSelector("div.sc-87f10045-7:nth-child(2) > p:nth-child(1) > a:nth-child(1) > span:nth-child(2)"));

        String availabilityText = availability.getText();

        assertEquals("Tillgänglighet i SVT Play", availabilityText, "Linktext does not match");

*/
    }
    @AfterAll
    static void teardown() {driver.quit();


    }
}

